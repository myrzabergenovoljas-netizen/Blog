from django.urls import path

from . import views

urlpatterns = [
    path("", views.ArticleListView.as_view(), name="article_list"),
    path("article/new/", views.ArticleCreateView.as_view(), name="article_create"),
    path("article/<int:pk>/", views.ArticleDetailView.as_view(), name="article_detail"),
    path("article/<int:pk>/edit/", views.ArticleUpdateView.as_view(), name="article_update"),
    path("article/<int:pk>/delete/", views.ArticleDeleteView.as_view(), name="article_delete"),
    path("article/<int:pk>/like/", views.toggle_like, name="article_like"),
    path("signup/", views.SignUpView.as_view(), name="signup"),
]
