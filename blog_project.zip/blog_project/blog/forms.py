from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Article, Comment

DT_FORMAT = "%Y-%m-%dT%H:%M"


class ArticleForm(forms.ModelForm):
    class Meta:
        model = Article
        fields = ["title", "content", "created_at", "category", "tags", "image"]
        widgets = {
            "created_at": forms.DateTimeInput(
                attrs={"type": "datetime-local"}, format=DT_FORMAT
            ),
            "content": forms.Textarea(attrs={"rows": 10}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["created_at"].input_formats = [DT_FORMAT, "%Y-%m-%d %H:%M:%S"]


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["text"]
        widgets = {
            "text": forms.Textarea(
                attrs={"rows": 3, "placeholder": "Ваш комментарий..."}
            )
        }
        labels = {"text": ""}


class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=False, label="Email")

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")
