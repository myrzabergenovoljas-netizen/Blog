from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from .forms import ArticleForm, CommentForm, SignUpForm
from .models import Article, Category


class ArticleListView(ListView):
    """Список статей — доступен всем, с пагинацией и фильтром по категории."""

    model = Article
    template_name = "blog/article_list.html"
    context_object_name = "articles"
    paginate_by = 5

    def get_queryset(self):
        qs = (
            Article.objects.select_related("author", "category")
            .prefetch_related("likes")
        )
        category = self.request.GET.get("category")
        tag = self.request.GET.get("tag")
        if category:
            qs = qs.filter(category_id=category)
        if tag:
            qs = qs.filter(tags__icontains=tag)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["categories"] = Category.objects.all()
        ctx["current_category"] = self.request.GET.get("category", "")
        ctx["current_tag"] = self.request.GET.get("tag", "")
        # сохраняем фильтры в ссылках пагинации
        params = self.request.GET.copy()
        params.pop("page", None)
        ctx["query_string"] = params.urlencode()
        return ctx


class ArticleDetailView(DetailView):
    """Одна статья + комментарии (под статьёй, по порядку добавления)."""

    model = Article
    template_name = "blog/article_detail.html"
    context_object_name = "article"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["comments"] = self.object.comments.select_related("author")
        ctx["comment_form"] = CommentForm()
        user = self.request.user
        ctx["user_liked"] = (
            user.is_authenticated and self.object.likes.filter(pk=user.pk).exists()
        )
        return ctx

    def post(self, request, *args, **kwargs):
        """Добавление комментария (только для авторизованных)."""
        if not request.user.is_authenticated:
            return redirect(f"{reverse_lazy('login')}?next={request.path}")
        self.object = self.get_object()
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.article = self.object
            comment.author = request.user
            comment.save()
            messages.success(request, "Комментарий добавлен.")
            return redirect(self.object.get_absolute_url())
        ctx = self.get_context_data(object=self.object)
        ctx["comment_form"] = form
        return self.render_to_response(ctx)


class ArticleCreateView(LoginRequiredMixin, CreateView):
    model = Article
    form_class = ArticleForm
    template_name = "blog/article_form.html"

    def form_valid(self, form):
        form.instance.author = self.request.user
        messages.success(self.request, "Статья опубликована.")
        return super().form_valid(form)


class AuthorRequiredMixin(UserPassesTestMixin):
    """Редактировать/удалять статью может только её автор."""

    def test_func(self):
        return self.get_object().author == self.request.user


class ArticleUpdateView(LoginRequiredMixin, AuthorRequiredMixin, UpdateView):
    model = Article
    form_class = ArticleForm
    template_name = "blog/article_form.html"

    def form_valid(self, form):
        messages.success(self.request, "Статья обновлена.")
        return super().form_valid(form)


class ArticleDeleteView(LoginRequiredMixin, AuthorRequiredMixin, DeleteView):
    model = Article
    template_name = "blog/article_confirm_delete.html"
    success_url = reverse_lazy("article_list")

    def form_valid(self, form):
        messages.success(self.request, "Статья удалена.")
        return super().form_valid(form)


@login_required
def toggle_like(request, pk):
    if request.method != "POST":
        return redirect("article_detail", pk=pk)
    article = get_object_or_404(Article, pk=pk)
    if article.likes.filter(pk=request.user.pk).exists():
        article.likes.remove(request.user)
    else:
        article.likes.add(request.user)
    return redirect(request.POST.get("next") or article.get_absolute_url())


class SignUpView(CreateView):
    form_class = SignUpForm
    template_name = "registration/signup.html"
    success_url = reverse_lazy("article_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)  # сразу входим после регистрации
        messages.success(self.request, "Добро пожаловать! Регистрация прошла успешно.")
        return response
